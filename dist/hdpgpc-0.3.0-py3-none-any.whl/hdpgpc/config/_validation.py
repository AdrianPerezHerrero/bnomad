"""New-API validation; never clip parameters or repair legacy algorithms."""

import math
from numbers import Integral, Real


def integer(value, name, minimum=0, optional=False):
    if optional and value is None:
        return
    if isinstance(value, bool) or not isinstance(value, Integral) or value < minimum:
        raise ValueError(f'{name} must be an integer >= {minimum}')


def boolean(value, name):
    if type(value).__name__ not in ('bool', 'bool_'):
        raise ValueError(name + ' must be boolean')


def validate_inference(c):
    if c.schedule not in (None, 'online', 'online_fast', 'offline'):
        raise ValueError('Unknown inference schedule')
    for name in ('with_warp', 'warp', 'classify', 'reestimate_initial_params'):
        boolean(getattr(c, name), name)
    for name in ('batch', 'force_model'):
        integer(getattr(c, name), name, optional=True)
    integer(c.minibatch, 'minibatch')
    integer(c.n_explore_steps, 'n_explore_steps')
    integer(c.it_limit, 'it_limit', 1, optional=True)
    if c.schedule == 'offline' and (c.force_model is not None or c.minibatch != 0 or c.classify):
        raise ValueError('force_model/minibatch/classify apply only to online inference')
    if c.schedule in ('online', 'online_fast') and (c.it_limit is not None or c.warp):
        raise ValueError('it_limit/warp apply to offline inference; online uses with_warp')


def validate_numerics(n):
    boolean(n.cuda, 'cuda')
    integer(n.seed, 'seed', optional=True)
    if n.seed is not None and n.seed >= 2**32:
        raise ValueError('seed must fit NumPy uint32')
    integer(n.num_threads, 'num_threads', 1, optional=True)
    if n.dtype not in (None, 'float64'):
        raise ValueError('Only the existing float64 formulation is supported')
    if n.deterministic is not None:
        boolean(n.deterministic, 'deterministic')


def validate(c, *, for_build=False):
    from ._models import SECTIONS
    for name, typ in SECTIONS.items():
        if type(getattr(c, name)) is not typ:
            raise TypeError(name + ' must be ' + typ.__name__)
    import numpy as np
    h, e, d, a, i, o, n = (getattr(c, k) for k in SECTIONS)
    integer(h.M, 'M', 1, optional=True)
    M = 1 if h.M is None else h.M
    integer(h.max_models, 'max_models', 1, optional=True)
    if h.max_models is not None and h.max_models < M:
        raise ValueError('max_models cannot be smaller than initial M')
    if h.hdp_hyp not in ('less', 'balanced', 'more'):
        raise ValueError('hdp_hyp must be less, balanced or more')
    integer(o.n_outputs, 'n_outputs', 1)
    for obj, names in ((c, ('verbose',)), (h, ('hmm_switch',)),
                       (e, ('check_var',)), (d, ('bayesian_params',)),
                       (o, ('share_gp', 'use_snr', 'reduce_outputs')), (n, ('cuda',))):
        for name in names:
            boolean(getattr(obj, name), name)
    if not isinstance(o.reduce_outputs_ratio, Real) or not 0 < o.reduce_outputs_ratio <= 1:
        raise ValueError('reduce_outputs_ratio must be in (0, 1]')
    if o.reduce_outputs and int(np.rint(o.n_outputs * o.reduce_outputs_ratio)) < 1:
        raise ValueError('Output reduction would leave zero outputs')
    validate_inference(i)
    if a.policy not in ('gp', 'none'):
        raise ValueError('Unknown alignment policy')
    if a.method_compute_warp not in ('standard', 'greedy', 'greedy_bound'):
        raise ValueError('Unknown alignment method')
    if a.mode_warp not in ('balanced', 'fine', 'rough'):
        raise ValueError('Unknown alignment mode')
    if not isinstance(a.noise_warp, Real) or not math.isfinite(a.noise_warp) or a.noise_warp <= 0:
        raise ValueError('noise_warp must be finite and positive')
    # NoAlignment deliberately overrides True request flags: that is valid.
    validate_numerics(n)
    integer(d.free_deg_MNIV, 'free_deg_MNIV', 1)
    if not isinstance(d.reest_conditions, (list, tuple)) or len(d.reest_conditions) != 3:
        raise ValueError('reest_conditions must contain min_samples, max_samples, divisor')
    for v in d.reest_conditions:
        integer(v, 'reest_conditions entry', 1)
    if d.reest_conditions[0] > d.reest_conditions[1]:
        raise ValueError('Minimum re-estimation samples exceeds maximum')

    def clusters(value, name):
        if isinstance(value, (list, np.ndarray)):
            if len(value) < M:
                raise ValueError(name + ' has fewer entries than initial M')
            return list(value)
        return [value]

    for value in clusters(d.model_type, 'model_type'):
        if value not in ('static', 'dynamic'):
            raise ValueError('model_type must be static or dynamic')
    for obj, names in ((e, ('inducing_points',)), (d, ('annealing',)),
                       (a, ('recursive_warp', 'warp_updating'))):
        for name in names:
            for value in clusters(getattr(obj, name), name):
                boolean(value, name)
    for value in clusters(d.estimation_limit, 'estimation_limit'):
        integer(value, 'estimation_limit', 1, optional=True)
    for obj, names in ((e, ('ini_lengthscale', 'ini_sigma', 'ini_outputscale')), (d, ('ini_gamma',))):
        for name in names:
            for value in clusters(getattr(obj, name), name):
                if value is None:
                    continue
                array = np.asarray(value)
                if array.dtype.kind not in 'iuf' or not np.all(np.isfinite(array)):
                    raise ValueError(name + ' must contain finite numerical values')
                if array.ndim == 0 and value <= 0:
                    raise ValueError(name + ' must be positive')
    for obj, names in ((e, ('bound_lengthscale', 'bound_sigma')), (d, ('bound_gamma',)), (a, ('bound_noise_warp',))):
        for name in names:
            for value in clusters(getattr(obj, name), name):
                if value is None:
                    continue
                bounds = np.asarray(value)
                if bounds.shape != (2,) or bounds.dtype.kind not in 'iuf' or not np.all(np.isfinite(bounds)):
                    raise ValueError(name + ' must be a bound pair (or per-cluster pairs)')
                if bounds[0] <= 0 or bounds[1] < bounds[0]:
                    raise ValueError(name + ' requires 0 < lower <= upper')
    if e.kernels is not None:
        from sklearn.gaussian_process.kernels import Kernel
        if not isinstance(e.kernels, (list, tuple)) or len(e.kernels) < M or not all(isinstance(k, Kernel) for k in e.kernels):
            raise ValueError('kernels must contain at least M sklearn kernels')
        from ._codec import encode
        for kernel in e.kernels:
            encode(kernel)  # reject nonserializable custom classes/callables explicitly
    for value, name in ((c.x_basis, 'x_basis'), (a.x_basis_warp, 'x_basis_warp')):
        if value is None:
            continue
        grids = value if isinstance(value, list) else [value]
        if isinstance(value, list) and len(value) < M:
            raise ValueError(name + ' has fewer grids than initial M')
        for grid in grids:
            if not isinstance(grid, np.ndarray) or grid.ndim not in (1, 2) or grid.size == 0:
                raise ValueError(name + ' requires nonempty NumPy grids (or a list of grids)')
            if grid.ndim == 2 and grid.shape[1] != 1:
                raise ValueError(name + ' must be one-dimensional coordinates')
            if not np.all(np.isfinite(grid)):
                raise ValueError(name + ' must contain finite coordinates')
    if for_build:
        if n.cuda:
            import torch
            if not torch.cuda.is_available():
                raise ValueError('CUDA requested but unavailable on this host')
        if c.x_basis is None:
            raise ValueError('x_basis is required to build a model')
        required = [(e.ini_sigma, 'ini_sigma'), (d.ini_gamma, 'ini_gamma'),
                    (e.bound_sigma, 'bound_sigma'), (d.bound_gamma, 'bound_gamma'),
                    (a.bound_noise_warp, 'bound_noise_warp')]
        if e.kernels is None:
            required += [(e.ini_lengthscale, 'ini_lengthscale'), (e.bound_lengthscale, 'bound_lengthscale')]
        for value, name in required:
            if any(v is None for v in clusters(value, name)[:M]):
                raise ValueError(name + ' must be supplied; its legacy default remains None')
