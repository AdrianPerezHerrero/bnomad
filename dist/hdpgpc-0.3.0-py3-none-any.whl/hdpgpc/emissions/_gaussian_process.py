#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Native cluster/output GP emission and coupled LDS trajectory.
Prior/prediction operations live in _prior; fitting in _training; LDS in dynamics.
Original algorithms by Adrian Perez Herrero, retained without numerical changes."""
from ._prior import GaussianProcessPrior
import numpy as np
import torch
from tqdm import trange
import math
from bisect import bisect_right
from ..dynamics._models import _LINEAR, _STATIC
from ..dynamics import _trajectory
from ..dynamics._distributions import matrix_normal_inv_wishart, inv_wishart
dtype = torch.float64
torch.set_default_dtype(dtype)

class GaussianProcessEmission:
    """Model that sum up all the information to characterise a GPR_iterative_model.
        Parameters
        ----------
        kernel : kernel from sklearn class for covariance computation.

        x_basis : array-like of shape (s_samples) domain points where is wanted
        to focus the learning.

        ini_Sigma : positive double or array-like of shape (n_samples) noise associated with subyacent process.
        Returns
        -------
        self : returns an instance of self.
        """

    def __init__(self, kernel, x_basis, annealing=True, bayesian=False, cuda=False, inducing_points=False,
                 estimation_limit=None, free_deg_MNIV=5, verbose=True):
        self.gp = GaussianProcessPrior(kernel, x_basis, cuda=cuda, verbose=verbose)
        self.x_basis = self.cond_to_torch(x_basis)
        self.x_train = []
        self.y_train = []
        self.f_star = []
        self.f_star_sm = []
        self.cov_f = []
        self.cov_f_sm = []
        self.y_var = []
        self.var = []
        self.A = []
        self.Gamma = []
        self.C = []
        self.Sigma = []
        self.likelihood = []
        self.N = 0
        self.indexes = []
        self.K = self.cond_to_torch(kernel(self.cond_to_cpu(x_basis), self.cond_to_cpu(x_basis)))
        self.annealing = annealing
        self.bayesian = bayesian
        self.cuda = cuda
        self.inducing_points = inducing_points
        if bayesian:
            self.internal_params = None
            self.observation_params = None
        if estimation_limit is None:
            estimation_limit = np.inf
        self.estimation_limit = estimation_limit
        self.fitted = False
        self.A_def, self.Gamma_def, self.C_def, self.Sigma_def = None, None, None, None
        self.ini_cov_def = None
        self.ini_kernel_theta = self.gp.kernel.theta

        if self.cuda:
            self.device = 'cuda'
        else:
            self.device = 'cpu'
        self.sq_lat_last = torch.zeros(1, device=self.device)
        self.free_deg_MNIV = free_deg_MNIV
        self.verbose = verbose
        self.disable = not verbose

    def _eye_cached(self, n, device, dtype):
        if not hasattr(self, "_eye_cache"):
            self._eye_cache = {}
        key = (n, str(device), dtype)
        if key not in self._eye_cache:
            self._eye_cache[key] = torch.eye(n, device=device, dtype=dtype)
        return self._eye_cache[key]

    def _chol_spd(self, M, jitter_scale=1e-8):
        M = 0.5 * (M + M.T)
        eye = self._eye_cached(M.shape[0], M.device, M.dtype)
        diag_mean = torch.mean(torch.diag(M).abs()).clamp_min(torch.finfo(M.dtype).eps)
        return torch.linalg.cholesky(M + jitter_scale * diag_mean * eye)

    def _log2pi(self, ref):
        return torch.tensor(math.log(2.0 * math.pi), device=ref.device, dtype=ref.dtype)

    def _gaussian_score_shared_cov(self, Y, mean, cov):
        """
        Y    : (B,T,1) or (B,T)
        mean : (T,1) or (T,)
        cov  : (T,T)
        returns: (B,)
        """
        if Y.ndim == 3:
            Y2 = Y[..., 0].T  # (T,B)
        else:
            Y2 = Y.T  # (T,B)

        if mean.ndim == 2:
            m = mean[:, 0:1]  # (T,1)
        else:
            m = mean.unsqueeze(1)  # (T,1)

        diff = Y2 - m  # (T,B)
        L = self._chol_spd(cov)
        alpha = torch.cholesky_solve(diff, L)
        q = diff.shape[0]
        return -0.5 * torch.sum(diff * alpha, dim=0) - 0.5 * q * self._log2pi(diff)

    def initial_conditions(self, ini_mean=None, ini_cov=None,
                           ini_A=None, ini_Gamma=None, ini_C=None, ini_Sigma=None):
        """
        Incorporate initial conditions to the model, if none is specified default
        model is a dynamic one.
        Parameters
        ----------
        ini_mean : array like
            DESCRIPTION. Initial mean of the model. The default is 0.
        ini_cov : matrix like
            DESCRIPTION. Initial covariance of the model, should be computed
            using hyperparameters kernel stimation. The default is None.
        ini_A : matrix like
            DESCRIPTION. Projection step matrix. The default is Id.
        ini_Gamma : matrix like
            DESCRIPTION. Noise associated with the subsequent process. The default is 0.01.
        ini_C : matrix like
            DESCRIPTION. Projection observations matrix. The default is Id.
        ini_Sigma : matrix like
            DESCRIPTION. Noise associated with observations. The default is 0.5**2.

        Returns
        -------
        None.

        """
        # Incorporate initial parameters
        if ini_mean is None:
            self.f_star.append(self.compute_mean())
            self.f_star_sm.append(self.compute_mean())
        else:
            self.f_star.append(self.cond_to_torch(ini_mean))
            self.f_star_sm.append(self.cond_to_torch(ini_mean))
        if ini_cov is None:
            self.cov_f.append(self.cond_to_torch(self.K))
            self.cov_f_sm.append(self.cond_to_torch(self.K))
            self.ini_cov_def = self.K.clone()
        else:
            self.cov_f.append(self.cond_to_torch(ini_cov))
            self.cov_f_sm.append(self.cond_to_torch(ini_cov))
            self.ini_cov_def = ini_cov
        if ini_A is None and ini_Gamma is None and ini_C is None and ini_Sigma is None:
            ini_A, ini_Gamma, ini_C, ini_Sigma = self.GPR_dynamic()

        self.A.append(ini_A)
        self.Gamma.append(ini_Gamma)
        self.C.append(ini_C)
        self.Sigma.append(ini_Sigma)
        self.A_def = self.cond_to_cuda(self.cond_to_torch(ini_A))
        self.Gamma_def = self.cond_to_cuda(self.cond_to_torch(ini_Gamma))
        self.C_def = self.cond_to_cuda(self.cond_to_torch(ini_C))
        self.Sigma_def = self.cond_to_cuda(self.cond_to_torch(ini_Sigma))
        self.var.append(np.atleast_2d(np.diag(ini_Gamma)).T)
        self.y_var.append(np.atleast_2d(np.diag(ini_Sigma)).T)
        # DEGREES OF FREEDOM AT LEAST 3
        if self.bayesian:
            self.internal_params = matrix_normal_inv_wishart(ini_A, np.eye(ini_A.shape[0]),  self.free_deg_MNIV, ini_Gamma)
            if torch.all(ini_Gamma == torch.zeros(ini_Gamma.shape)):
                self.observation_params = inv_wishart(self.free_deg_MNIV, ini_Sigma, ini_C)
            else:
                self.observation_params = matrix_normal_inv_wishart(ini_C, np.eye(ini_C.shape[0]), self.free_deg_MNIV, ini_Sigma)


    def GPR_static(self, ini_Sigma=None):
        """ Define static conditions using initial Sigma as a double.
        """
        return _STATIC.initial_parameters(self.x_basis, sigma=ini_Sigma)

    def GPR_dynamic(self, gamma=None, sigma=None):
        """ Define dynamic conditions using initial Sigma as a double.
        """
        return _LINEAR.initial_parameters(self.x_basis, sigma=sigma, gamma=gamma)

    def fit_kernel_params(self, x_train, y, alpha_ini, gamma_ini, valid=True):
        """ Optimize RBF kernel hyperparameters
        """
        alph_ = self.cond_to_torch(alpha_ini[0][0])
        gam_ = self.cond_to_torch(gamma_ini[0][0])
        if valid:
            fitted = self.gp.fit_torch(self.cond_to_torch(x_train), self.cond_to_torch(y), alph_, gam_,
                                       reduced_points=self.inducing_points, verbose=self.verbose)
        noise = self.gp.kernel.get_params()["k2__noise_level"]
        noise = alph_
        self.x_basis = self.cond_to_cuda(self.cond_to_torch(self.gp.x_basis))
        self.Sigma[-1] = self.cond_to_cuda(self.cond_to_torch(torch.mul(noise, torch.eye(len(self.x_basis), device=noise.device))))
        self.Sigma_def = torch.clone(self.Sigma[-1])
        self.y_var[-1] = self.cond_to_cuda(self.cond_to_torch(np.atleast_2d(np.diag(self.cond_to_cpu(self.Sigma[-1]))).T))
        self.C[-1] = self.cond_to_cuda(torch.eye(len(self.x_basis)))
        self.A[-1] = self.cond_to_cuda(torch.eye(len(self.x_basis)))
        self.Gamma[-1] = self.cond_to_cuda(self.cond_to_torch(torch.mul(torch.mean(torch.diag(self.Gamma[-1])),
                                                                        torch.eye(len(self.x_basis), device=self.device))))
        self.f_star[-1] = self.cond_to_cuda(self.cond_to_torch(self.compute_mean()))
        self.f_star_sm[-1] = self.cond_to_cuda(self.cond_to_torch(self.compute_mean()))
        ini_cov = self.cond_to_cuda(self.cond_to_torch(
            self.gp.kernel(self.cond_to_numpy(self.cond_to_cpu(self.x_basis)),
                           self.cond_to_numpy(self.cond_to_cpu(self.x_basis)))))# + self.Sigma[-1]
        self.ini_cov_def = ini_cov
        self.cov_f[-1] = ini_cov
        self.cov_f_sm[-1] = ini_cov
        if self.bayesian:
            self.observation_params.set_scale(self.cond_to_cuda(self.cond_to_torch(torch.mul(noise, torch.eye(len(self.x_basis), device=noise.device)))))
            self.observation_params.m_mean = self.C[-1]
            self.internal_params.set_scale(self.Gamma[-1])
            self.internal_params.m_mean = self.A[-1]
        self.fitted = True
        print("---Kernel estimated---")
        print(self.gp.kernel)
        return self.x_basis, ini_cov

    def log_lik_sample(self, y):
        """Returns log-likelihood of a single sample using the last state of the model.
        """
        lik_post = self.gp.log_likelihood(self.N, self.N, self.f_star_sm, self.cov_f_sm, self.A[-1], self.Gamma[-1], y,
                                          self.C[-1], self.Sigma[-1])
        return lik_post

    def log_sq_error(self, x_train, y, mean=None, cov=None, C=None, Sigma=None, i=None, proj=False, first=False):
        """Compute the log-squared-error of a sample assuming a specific iteration of the model."""
        y = self.cond_to_cuda(self.cond_to_torch(y)).to(torch.float64)
        mean = self.cond_to_torch(mean)
        cov = self.cond_to_torch(cov)
        C = self.cond_to_torch(C)
        Sigma = self.cond_to_torch(Sigma)

        if x_train is None:
            x_train = self.x_basis

        if mean is None:
            params = None
        else:
            params = [mean, cov, C, Sigma]

        if i is not None:
            f_star, cov_f = self.observe(x_train, i, params, proj=proj)
        else:
            f_star, cov_f = self.step_forward_last(x_train, params)

        if first:
            ini_noise = torch.mean(torch.diag(self.Sigma[0])) * 1e-2
            cov_f = cov_f + ini_noise * self._eye_cached(len(x_train), cov_f.device, cov_f.dtype)

        if y.ndim == 1:
            y = y.unsqueeze(-1)
        if f_star.ndim == 1:
            f_star = f_star.unsqueeze(-1)

        diff = y - f_star
        L = self._chol_spd(cov_f)
        alpha = torch.cholesky_solve(diff, L)
        q = diff.shape[0]

        err = -0.5 * torch.sum(diff * alpha) - 0.5 * q * self._log2pi(diff)
        return err

    def log_lat_error(self, i, h_ini):
        """Compute the log-squared-error of the latent process."""
        if i == 0:
            cov_f_prev = self.cov_f_sm[i + 1]
            lat_prev = self.f_star_sm[i + 1]
            Gamma_mat = self.Gamma[-1] * h_ini
            A = self.A[-1]
        else:
            cov_f_prev = self.cov_f_sm[i]
            lat_prev = self.f_star_sm[i]
            if i + 1 < len(self.Gamma):
                Gamma_mat = self.Gamma[i + 1]
                A = self.A[i + 1]
            else:
                Gamma_mat = self.Gamma[-1]
                A = self.A[-1]

        lat_cur = self.f_star_sm[i + 1]

        if lat_prev.ndim == 1:
            lat_prev = lat_prev.unsqueeze(-1)
        if lat_cur.ndim == 1:
            lat_cur = lat_cur.unsqueeze(-1)

        resid = lat_cur - A @ lat_prev
        Lg = self._chol_spd(Gamma_mat)

        alpha_resid = torch.cholesky_solve(resid, Lg)  # Gamma^{-1} resid
        Gamma_inv_A = torch.cholesky_solve(A, Lg)  # Gamma^{-1} A

        q = resid.shape[0]
        mahal = torch.sum(resid * alpha_resid)
        trace_term = torch.trace(A.T @ Gamma_inv_A @ cov_f_prev)

        err = -0.5 * (mahal + trace_term) - 0.5 * q * self._log2pi(resid)
        return err

    def condition_observation(self, index, x_train, y, x_warped=None, h=1.0, posterior=True, embedding=True, include_index=False):
        """ Method to include sample in the model, compute the posterior and add the data.
        """
        if posterior:
            self.N = self.N + 1
            self.indexes.append(index)
            self.x_train.append(x_train)
            self.y_train.append(self.cond_to_torch(y))
            f_star_, cov_f_ = self.gp.posterior(self.f_star_sm[-1], self.cov_f_sm[-1], self.y_train[-1], self.A[-1],
                                                self.Gamma[-1], self.C[-1], self.Sigma[-1] / h, x_train=x_train,
                                                x_warped=x_warped, embedding=embedding)
            self.f_star.append(f_star_)
            self.f_star_sm.append(f_star_)
            self.cov_f.append(cov_f_)
            self.cov_f_sm.append(cov_f_)
            return self.f_star_sm[-1], self.cov_f_sm[-1]
        else:
            if include_index:
                self.indexes.append(index)
                self.x_train.append(x_train)
                self.y_train.append(self.cond_to_torch(y))
                f_star_, cov_f_ = self.f_star_sm[-1], self.cov_f_sm[-1]
                self.f_star.append(f_star_)
                self.f_star_sm.append(f_star_)
                self.cov_f.append(cov_f_)
                self.cov_f_sm.append(cov_f_)
            return self.f_star_sm[-1], self.cov_f_sm[-1]

    def include_weighted_sample(self, index, x_train, x_warped, y, h, snr=None):
        """Method to include the sample depending on the responsibility h.
        """
        y = self.cond_to_cuda(self.cond_to_torch(y))
        x_train = self.cond_to_cuda(self.cond_to_torch(x_train))
        new_x_basis = self.x_basis
        #Responsability truncated to 0.9 for stability purposes.
        if h == 1.0:
            if self.N == 0 and not self.fitted:
                if torch.allclose(torch.from_numpy(self.gp.kernel.theta), torch.from_numpy(self.ini_kernel_theta)):
                    new_x_basis, _ = self.fit_kernel_params(x_train, y, self.Sigma[-1], self.Gamma[-1], valid=True)
                else:
                    new_x_basis, _ = self.fit_kernel_params(x_train, y, self.Sigma[-1], self.Gamma[-1], valid=False)
            if snr is not None:
                if snr > 0.5:
                    self.condition_observation(index, x_train, y, x_warped, h=1.0)
                else:
                    self.condition_observation(index, x_train, y, x_warped, posterior=False, include_index=True)
            else:
                self.condition_observation(index, x_train, y, x_warped, h=1.0)
        else:
            self.condition_observation(index, x_train, y, x_warped, posterior=False)
        return new_x_basis

    def full_pass_weighted(self, x_trains, y_trains, resp, q=None, q_lat=None, snr=None):
        """Full forward pass method used in the offline scheme."""
        if len(torch.nonzero(self.Gamma[-1])) < 1:
            model_type = 'static'
        else:
            model_type = 'dynamic'

        active = torch.nonzero(resp > 0.99, as_tuple=False).squeeze(1)
        if active.numel() == 0:
            return q, q_lat

        for index in active.tolist():
            h = float(resp[index].item())
            self.include_weighted_sample(
                index,
                x_trains[index],
                x_trains[index],
                y_trains[index],
                h
            )
            if model_type == 'dynamic':
                self.backwards_pair(h)
                self.bayesian_new_params(h)

        if model_type == 'dynamic':
            self.backwards()

        q_ = self.compute_sq_err_all(x_trains, y_trains)
        q_lat_ = self.compute_q_lat_all(x_trains)
        return q_, q_lat_

    def reinit_GP(self, save_last=False, save_index=False):
        """ Method to reinitiate GP parameters. Can save some of them.
        """
        if save_last:
            self.y_var = [self.y_var[0],self.y_var[-1]]
            self.var = [self.var[0],self.var[-1]]
            self.f_star = [self.f_star[0],self.f_star[-1]]
            self.f_star_sm = [torch.clone(self.f_star[0]),torch.clone(self.f_star[-1])]
            self.cov_f = [self.cov_f[0],self.cov_f[-1]]
            self.cov_f_sm = [self.cov_f_sm[0],self.cov_f_sm[-1]]
            self.y_train = []
            self.x_train = []
            if not save_index:
                self.indexes = [0]

        else:
            self.y_var = self.y_var[:1]
            self.var = self.var[:1]
            self.f_star = self.f_star[:1]
            self.f_star_sm = self.f_star[:1].copy()
            self.cov_f = [torch.clone(self.ini_cov_def)]
            self.cov_f_sm = [torch.clone(self.ini_cov_def)]
            self.indexes = []
            self.y_train = []
            self.x_train = []
        self.likelihood = []
        self.N = 0


    def reinit_LDS(self, save_last=False, save_last_diag=False, return_likelihood=False):
        """ Method to reinitiate LDS parameters. Can save some of them.
        """
        return _trajectory.reinit_LDS(self, save_last, save_last_diag, return_likelihood)

    def return_LDS_param_likelihood(self, first=False):
        """ Method to compute the likelihood of LDS parameters over the prior.
        """
        return _trajectory.return_LDS_param_likelihood(self, first)

    def compute_sq_err_all(self, x_trains, y_trains, no_first=False):
        """Method to compute the squared error over all provided examples y_trains."""
        n_samps = x_trains.shape[0]
        device = x_trains.device if torch.is_tensor(x_trains) else x_trains[0].device
        sq_err = torch.zeros(n_samps, device=device, dtype=torch.float64)

        if len(self.indexes) == 0:
            return sq_err

        idx_t = torch.as_tensor(self.indexes, device=device, dtype=torch.long)
        sample_ids = torch.arange(n_samps, device=device, dtype=torch.long)

        pos_of_sample = torch.full((n_samps,), -1, device=device, dtype=torch.long)
        pos_of_sample[idx_t] = torch.arange(idx_t.numel(), device=device, dtype=torch.long)

        exact_mask = pos_of_sample >= 0
        closest_pos0 = torch.searchsorted(idx_t, sample_ids, right=True) - 1
        closest_pos0 = torch.clamp(closest_pos0, min=0)

        # Keep your current behavior
        i_vals = torch.where(
            exact_mask,
            pos_of_sample + 1,
            torch.clamp(closest_pos0, min=1)
        )
        first_mask = exact_mask & (i_vals == 1) & (not no_first)

        # Fast path only if all samples share the same x-grid
        shared_grid = torch.equal(x_trains, x_trains[0:1].expand_as(x_trains))
        if shared_grid:
            x0 = x_trains[0]
            group_code = i_vals * 2 + first_mask.to(i_vals.dtype)

            for code in torch.unique(group_code):
                ids = torch.nonzero(group_code == code, as_tuple=False).squeeze(1)
                i_cur = int((code // 2).item())
                first_cur = bool((code % 2).item())

                f_star, cov_f = self.observe(x0, i_cur, params=None, proj=False)
                if first_cur:
                    ini_noise = torch.mean(torch.diag(self.Sigma[0])) * 1e-2
                    cov_f = cov_f + ini_noise * self._eye_cached(len(x0), cov_f.device, cov_f.dtype)

                sq_err[ids] = self._gaussian_score_shared_cov(y_trains[ids], f_star, cov_f)

            return sq_err

        # Fallback for irregular x-grids
        i_vals_cpu = i_vals.cpu().tolist()
        first_mask_cpu = first_mask.cpu().tolist()

        for index in trange(n_samps, desc="Compute_sq_error", disable=self.disable):
            sq_err[index] = self.log_sq_error(
                x_trains[index],
                y_trains[index],
                i=i_vals_cpu[index],
                first=first_mask_cpu[index],
            )

        return sq_err

    def compute_q_lat_all(self, x_trains, h_ini=1.0):
        """Method to compute the latent squared error accumulated.
        """
        sq_err = torch.zeros(x_trains.shape[0], device=x_trains[0].device)
        if self.N == 0:
            return sq_err
        if len(torch.nonzero(self.Gamma[-1]))< 1:
            return sq_err
        for j, index in enumerate(self.indexes):
            sq_err[index] = self.log_lat_error(j, h_ini)
        return sq_err

    def posterior_weighted(self, x_train, y, h, t=None):
        """ Method to compute the posterior depending on the responsibility h.
        """
        y = self.cond_to_torch(y)
        x_train = self.cond_to_torch(x_train)
        if h > 0.0:
            if t is not None and len(self.indexes) > t:
                f_star_sm_, cov_f_sm_ = self.f_star[t], self.cov_f[t]
                A, Gamma, C, Sigma = self.get_params(t)
            else:
                f_star_sm_ = self.f_star[-1]
                cov_f_sm_ = self.cov_f[-1]
                A = self.A[-1]
                Gamma = self.Gamma[-1]
                C = self.C[-1]
                Sigma = self.Sigma[-1]
            f_star_, cov_f_ = self.gp.posterior(f_star_sm_, cov_f_sm_, y, A,
                                                Gamma / h, C, Sigma / h, x_train=x_train, h=h)
        else:
            f_star_ = torch.clone(self.f_star[-1])
            cov_f_ = torch.clone(self.cov_f[-1])
        return f_star_, cov_f_

    def find_closest_lower(self, t):
        """Method to compute the closest last sample added to the model.
        """
        #List is assumed sorted
        lst = self.indexes
        idx = bisect_right(lst, t)
        if idx:
            return idx-1
        else:
            return 0

    def step_forward_last(self, x_post, params=None):
        """ Compute the observation over new x_post.
        """
        if params is None:
            C = self.C[-1]
            A = self.A[-1]
            Gamma = self.Gamma[-1]
            Sigma = self.Sigma[-1]
            mean = self.f_star_sm[-1]
            cov = self.cov_f_sm[-1]
        else:
            A = self.A[-1]
            Gamma = self.Gamma[-1]
            mean = params[0]
            cov = params[1]
            C = params[2]
            Sigma = params[3]
        mean = torch.linalg.multi_dot([C, mean])
        Sigma = Sigma# + torch.linalg.multi_dot([C, Gamma, C.T])
        x_basis = self.x_basis
        return self.gp.pred_dist(x_post, x_basis, mean, Sigma)

    def observe_last(self, x_post):
        """ Compute the last observation distribution over new x_post.
        """
        C = self.C[-1]
        Sigma = self.Sigma[-1]
        mean = torch.matmul(C, self.f_star_sm[-1])
        x_basis = self.x_basis
        return self.gp.pred_dist(x_post, x_basis, mean, Sigma)

    def observe(self, x_post, t, params=None, proj=False):
        """
        Method to resample the emission GP distribution at time t or using the parameters given.
        :param x_post: time set to resample
        :param t: step n where to resample the model
        :param params: tuple (mean, cov, Gamma, Sigma)
        """
        if params is None:
            #Case when model is not initialited
            if len(self.indexes) == 0:
                C = self.C[0]
                Sigma = self.Sigma[0]
                mean = torch.matmul(C, self.f_star[0])
            #Case when computing error with last (predict)
            elif len(self.indexes) <= t:
                C = self.C[-1]
                Sigma = self.Sigma[-1]
                A = self.A[-1]
                Gamma = self.Gamma[-1]
                mean = torch.linalg.multi_dot([C, self.f_star[-1]])
            elif self.estimation_limit <= t:
                C = self.C[-1]
                Sigma = self.Sigma[-1]
                if proj:
                    Sigma = Sigma + self.Gamma[-1]
                mean = torch.matmul(C, self.f_star[t])
            else:
                A, Gamma, C, Sigma = self.get_params(t)
                if proj:
                    Sigma = Sigma + Gamma
                mean = torch.matmul(C, self.f_star[t])
        else:
            mean = params[0]
            Sigma = params[3]
            mean = torch.matmul(params[2], mean)
        x_basis = self.x_basis
        return self.gp.pred_dist(x_post, x_basis, mean, Sigma)

    def get_params(self, t):
        """Method to return params on a specific iteration of the model
        """
        rest_len = len(self.C)
        ind = t if t < rest_len else -1
        return self.A[ind], self.Gamma[ind], self.C[ind], self.Sigma[ind]

    def resample_latent_mean(self, x_post, t=None, params=None):
        """Method to resample the latent process on a specific iteration of the model
        """
        if params is None:
            if t is None or t> len(self.indexes):
                mean = self.f_star_sm[-1]
                cov = self.cov_f_sm[-1]
            else:
                mean = self.f_star_sm[t]
                cov = self.cov_f_sm[t]
        else:
            mean = params[0]
            cov = params[1]
        x_basis = self.x_basis
        return self.gp.pred_latent_dist(x_post, x_basis, mean, cov)

    def backwards(self, h=1.0):
        """Method to compute backward recursion weighted by the responsibility.
        """
        return _trajectory.backwards(self, h)

    def backwards_pair(self, h, snr=None):
        """ Fast method to compute the last two backward iterations.
        """
        return _trajectory.backwards_pair(self, h, snr)

    def smoother_weighted(self, x_train, y, h):
        """ Method to compute the conditioned posterior and distribution if a sample is added.
        """
        f_star_aux, cov_f_aux = self.posterior_weighted(x_train, y, h)
        means = self.f_star.copy()
        means.append(f_star_aux)
        covs = self.cov_f.copy()
        covs.append(cov_f_aux)
        C = self.C.copy()
        C.append(self.C[-1])
        Sigma = self.Sigma.copy()
        Sigma.append(self.Sigma[-1])
        return means, covs, C, Sigma

    def smoother_weighted_index(self, x_train, y, h, t):
        """ Method to return the conditioned posterior and LDS parameters of a specific iteration of the model.
        """
        f_star_aux, cov_f_aux = self.posterior_weighted(x_train, y, h, t)
        A, Gamma, C, Sigma = self.get_params(t)
        return f_star_aux, cov_f_aux, C, Sigma

    def new_params(self, batch=None, reestimate=True, model_type='dynamic', verbose=True, check_var=False):
        """ Maximum Likelihood computation of the new LDS params.
        """
        return _trajectory.new_params(self, batch, reestimate, model_type, verbose, check_var)

    def check_bound_sigma(self, S):
        """ Method to check variance bounds (not actually used)
        """
        bounds = np.exp(self.gp.kernel.bounds[0]) ** 2
        for i in range(S.shape[0]):
            if S[i][i] < bounds[0]:
                S[i][i] = bounds[0]
            elif S[i][i] > bounds[1]:
                S[i][i] = bounds[1]
        return S

    def new_params_weighted(self, h, batch=None, reestimate=True, model_type='dynamic', min_samples=1, max_samples=6,
                            div_samples=15, verbose=True, check_var=False):
        """ Method to compute iteratively LDS params conditioned on the responsibility.
        """
        return _trajectory.new_params_weighted(self, h, batch, reestimate, model_type, min_samples, max_samples, div_samples, verbose, check_var)

    def revise_constraint_noise_step(self, Sigma_prior, Sigma_new):
        """ Method of natural gradient for covariance estimation (not actually used)
        """
        # Condition to ensure a minimal variance is required (occurs when two samples
        # are so similar and we assume a very certain model)
        if np.trace(Sigma_new) / np.trace(Sigma_prior) < 0.3 or np.trace(Sigma_new) / np.trace(Sigma_prior) > 2.0:
            # If reduces a third or doubles their medium diagonal variance value we assume is a strong assumption.
            Sigma_new = (Sigma_new + Sigma_prior) / 2
        return Sigma_new

    def KL_divergence(self, t, gpmodel, t_gp, smoothed=True, x_bas=None):
        """ Method to compute the Kullback-Leibler divergence over every iteration of two LDS models.
        """
        l1 = t
        l2 = t_gp
        if smoothed:
            f_m1 = self.f_star_sm[l1 + 1]
            f_m2 = gpmodel.f_star_sm[l2 + 1]
            cov_m1 = self.cov_f_sm[l1 + 1]
            cov_m2 = gpmodel.cov_f_sm[l2 + 1]
        else:
            f_m1 = self.f_star[l1 + 1]
            f_m2 = gpmodel.f_star[l2 + 1]
            cov_m1 = self.cov_f[l1 + 1]
            cov_m2 = gpmodel.cov_f[l2 + 1]
        if self.estimation_limit <= t:
            t = -1
        if gpmodel.estimation_limit <= t_gp:
            t_gp = -1
        if len(self.Gamma) == 0:
            return self.gp.KL_divergence(f_m1, cov_m1, f_m2, cov_m2)
        elif torch.all(self.Gamma[-1] == 0):
            return self.gp.KL_divergence(f_m1, cov_m1, f_m2, cov_m2)
        else:
            if x_bas is not None and not torch.equal(x_bas, self.x_basis):
                mean1, cov1 = self.observe(x_bas, t, params=[f_m1, cov_m1, self.C[t], self.Sigma[t]])
                mean2, cov2 = gpmodel.observe(x_bas, t_gp, params=[f_m2, cov_m2, gpmodel.C[t_gp], gpmodel.Sigma[t_gp]])
            else:
                mean1 = torch.matmul(self.C[t], f_m1)
                mean2 = torch.matmul(gpmodel.C[t_gp], f_m2)
                cov1 = torch.linalg.multi_dot([self.C[t], cov_m1, self.C[t].T]) + self.Sigma[t]
                cov2 = torch.linalg.multi_dot([gpmodel.C[t_gp], cov_m2, gpmodel.C[t_gp].T]) + gpmodel.Sigma[t_gp]
            return self.gp.KL_divergence(mean1, cov1, mean2, cov2)

    def compute_mean(self):
        """ Method to resample mean (usually zero mean)
        """
        return self.gp.compute_mean(self.x_basis)

    def plot_last(self, num_model):
        """ Predefined method to plot last iteration of the model.
        """
        if len(self.indexes) == 0:
            y = np.repeat(0, len(self.x_basis))
            x_train = np.repeat(0, len(self.x_basis))
        else:
            y = self.y_train[-1]
            x_train = self.x_train[-1]

        self.gp.plotGP(len(self.indexes) + num_model, self.x_basis,
                       np.dot(self.C[-1], self.f_star[-1]), np.sqrt(self.var[-1]),
                       x_train, y, np.sqrt(self.y_var[-1]),
                       title=True, label_model=num_model, labels=True)

    def sample_last(self, num_samples=1, random_state=0):
        """ Method to resample last GP as a distribution.
        """
        samples = self.gp.sample_y(self.f_star_sm[-1], self.cov_f_sm[-1], self.C[-1], self.Sigma[-1], num_samples,
                                   random_state).T
        rav_samples = []
        for i in range(num_samples):
            rav_samples.append(samples[i][0])
        return rav_samples

    def reduce_noise_matrix(self, x_basis=None, x_train=None):
        return self.gp.projection_matrix(x_basis, x_train)

    def bayesian_new_params(self, h, model_type='dynamic', full_data=False, q=None, force=False, snr=1.0):
        """ Method to compute the variational Bayesian step for LDS parameters. Can deal with dynamic or static models.
            Can use full data batch n-step estimation or 1-step estimation.
        """
        return _trajectory.bayesian_new_params(self, h, model_type, full_data, q, force, snr)


    #Methods to perform the conversion from NumPy to torch and from Cuda to cpu. Still have to solve this.
    def cond_to_numpy(self, x):
        if x is not None:
            if type(x) is torch.Tensor:
                x = x.detach().numpy()
        return x

    def cond_to_torch(self, x):
        if x is not None:
            if type(x) is not torch.Tensor:
                x = torch.from_numpy(np.array(x))
                x.requires_grad = False
            else:
                x.requires_grad = False
        return x

    def cond_to_cuda(self, x):
        if self.cuda:
            if x is not None:
                if type(x) is torch.Tensor and torch.cuda.is_available():
                    x = x.cuda()
                    x.requires_grad = False
        return x

    def cond_to_cpu(self, x):
        if x is not None:
            if type(x) is torch.Tensor:
                if x.is_cuda:
                    x = x.cpu()
        return x

    def model_to_numpy(self):
        def recursive_numpy(x):
            if type(x) is torch.Tensor:
                x = self.cond_to_numpy(x)
            elif type(x) is list:
                if len(x) > 0:
                    if type(x[0]) is torch.Tensor:
                        for j, i in enumerate(x):
                            x[j] = self.cond_to_numpy(i)
            else:
                x = x
            return x

        self.x_basis = recursive_numpy(self.x_basis)
        self.x_train = recursive_numpy(self.x_train)
        self.y_train = recursive_numpy(self.y_train)
        self.f_star = recursive_numpy(self.f_star)
        self.f_star_sm = recursive_numpy(self.f_star_sm)
        self.cov_f = recursive_numpy(self.cov_f)
        self.cov_f_sm = recursive_numpy(self.cov_f_sm)
        self.y_var = recursive_numpy(self.y_var)
        self.var = recursive_numpy(self.var)
        self.A = recursive_numpy(self.A)
        self.Gamma = recursive_numpy(self.Gamma)
        self.C = recursive_numpy(self.C)
        self.Sigma = recursive_numpy(self.Sigma)
        self.likelihood = recursive_numpy(self.likelihood)
        self.K = recursive_numpy(self.K)
        self.internal_params.to_numpy()
        self.observation_params.to_numpy()

    def model_to_torch(self):
        def recursive_torch(x):
            if type(x) is np.ndarray:
                x = self.cond_to_torch(x)
            elif type(x) is list:
                if len(x) > 0:
                    if type(x[0]) is np.ndarray or type(x[0]) is np.float64:
                        for j, i in enumerate(x):
                            x[j] = self.cond_to_torch(i)
            else:
                x = x
            return x

        self.x_basis = recursive_torch(self.x_basis)
        self.x_train = recursive_torch(self.x_train)
        self.y_train = recursive_torch(self.y_train)
        self.f_star = recursive_torch(self.f_star)
        self.f_star_sm = recursive_torch(self.f_star_sm)
        self.cov_f = recursive_torch(self.cov_f)
        self.cov_f_sm = recursive_torch(self.cov_f_sm)
        self.y_var = recursive_torch(self.y_var)
        self.var = recursive_torch(self.var)
        self.A = recursive_torch(self.A)
        self.Gamma = recursive_torch(self.Gamma)
        self.C = recursive_torch(self.C)
        self.Sigma = recursive_torch(self.Sigma)
        self.likelihood = recursive_torch(self.likelihood)
        self.K = recursive_torch(self.K)
        self.internal_params.to_torch()
        self.observation_params.to_torch()

    def model_to_cuda(self):
        if torch.cuda.is_available() and self.cuda:
            def recursive_cuda(x):
                if type(x) is torch.Tensor:
                    x = x.cuda()
                    x.requires_grad = False
                elif type(x) is list:
                    if len(x) > 0:
                        if type(x[0]) is torch.Tensor or type(x[0]) is torch.float64:
                            for j, i in enumerate(x):
                                x[j] = i.cuda()
                                x[j].requires_grad = False
                else:
                    x = x
                return x

            self.x_basis = recursive_cuda(self.x_basis)
            self.x_train = recursive_cuda(self.x_train)
            self.y_train = recursive_cuda(self.y_train)
            self.f_star = recursive_cuda(self.f_star)
            self.f_star_sm = recursive_cuda(self.f_star_sm)
            self.cov_f = recursive_cuda(self.cov_f)
            self.cov_f_sm = recursive_cuda(self.cov_f_sm)
            self.y_var = recursive_cuda(self.y_var)
            self.var = recursive_cuda(self.var)
            self.A = recursive_cuda(self.A)
            self.Gamma = recursive_cuda(self.Gamma)
            self.C = recursive_cuda(self.C)
            self.Sigma = recursive_cuda(self.Sigma)
            self.likelihood = recursive_cuda(self.likelihood)
            self.K = recursive_cuda(self.K)
            self.internal_params.to_cuda()
            self.observation_params.to_cuda()
            self.cuda = True
            self.gp.cuda = True

    def model_to_cpu(self):
        def recursive_cpu(x):
            if type(x) is torch.Tensor:
                x = x.cpu()
            elif type(x) is list:
                if len(x) > 0:
                    if type(x[0]) is torch.Tensor or type(x[0]) is torch.float64:
                        for j, i in enumerate(x):
                            x[j] = i.cpu()
            else:
                x = x
            return x

        self.x_basis = recursive_cpu(self.x_basis)
        self.x_train = recursive_cpu(self.x_train)
        self.y_train = recursive_cpu(self.y_train)
        self.f_star = recursive_cpu(self.f_star)
        self.f_star_sm = recursive_cpu(self.f_star_sm)
        self.cov_f = recursive_cpu(self.cov_f)
        self.cov_f_sm = recursive_cpu(self.cov_f_sm)
        self.y_var = recursive_cpu(self.y_var)
        self.var = recursive_cpu(self.var)
        self.A = recursive_cpu(self.A)
        self.Gamma = recursive_cpu(self.Gamma)
        self.C = recursive_cpu(self.C)
        self.Sigma = recursive_cpu(self.Sigma)
        self.likelihood = recursive_cpu(self.likelihood)
        self.K = recursive_cpu(self.K)
        self.internal_params.to_cpu()
        self.observation_params.to_cpu()
        self.cuda = False
        self.gp.cuda = False
