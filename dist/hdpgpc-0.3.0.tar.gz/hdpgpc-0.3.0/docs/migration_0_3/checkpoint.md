# Migration checkpoint

Target: breaking pre-1 release 0.3.0 in `npdc-0.3.0`. Original `npdc`, `npdc.zip`, and `HDP-GPC` are untouched.

- Inventory complete, line-level uses in inventory.json and ownership in inventory.md.
- Baseline source suite: 221 tests, 217 passed, 4 skips, 320.983 seconds. Initial wrong discovery invocation failed; corrected run is baseline-tests-corrected.log.
- Baseline notebooks: all eight executed twice with identical scientific reports; baseline-notebooks/validation.json.
- Six baseline workloads: repeated state hashes identical, timings and separate memory in baseline-benchmarks/.
- Stage 1: native emission class, native GP prior, separated GP fitting module, native AMTGP warp class; canonical imports. Root legacy files still present pending final removal.
- Stage 1 numerical and boundary gates running; inspect stage1-verified.log and stage1-boundaries.log. Initial import/assertion test-migration mistakes corrected; numerical fixtures unchanged.

Next: execute workspace migration_stage2.py and migration_tests2.py ONCE after stage1 gates pass; introduce typed native ModelState and responsibility modules. These scripts are mechanical source migrations, not runtime dependencies. Then repair canonical test instrumentation/API checks, run full exact regressions. Delete root legacy modules only after independent native path passes. Audit docs/examples/benchmarks, build/install in clean env, run notebooks and all final gates; compare benchmark hashes/time/memory; commit and finalize report.

Never regenerate frozen numerical fixtures or weaken tolerances. Existing known-failure cases remain protected.
